//Include Express, Axios and the base url of the api
const express = require("express");

//Axios is a library which helps you to use the api async with pug
const axios = require("axios");
const app = express();
const BASE_URL = "ParasiteBreachApi.btshub.lu";

//Include the pug engine (after installation) and the public folder 
app.set("view engine", "pug");
app.use(express.static(__dirname + '/public'));

//Render index.pug with the received data by query
app.get("/", async (req, res) => {
    const query = await axios.get(`${BASE_URL}/player`);
	res.render("index", { users: query });
});

//After clicking the view data button on index
app.get('/profile', async (req, res) => {	
	//Get userID out of the request
	const user = await axios.get(`${BASE_URL}/user/`+ req.query.id, { headers: { 'app-id': '601261ff63bb102690cbc3da' } });;
	
	//Render Profile site and send saved data to it
	res.render("profile", {userData: user.data});
  });


//Port Stuff
const PORT = 5431;
app.listen(PORT, () => {
	console.log(`Listening on port ${PORT}...`);
});